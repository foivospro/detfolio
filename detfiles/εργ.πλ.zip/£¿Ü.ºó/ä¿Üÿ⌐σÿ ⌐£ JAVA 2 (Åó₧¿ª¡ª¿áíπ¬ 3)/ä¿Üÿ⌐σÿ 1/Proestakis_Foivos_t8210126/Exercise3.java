import java.util.Scanner;
public class Exercise3 {
static boolean isprime[];
		public static void main (String[] args){
		    	int x;
		        Scanner input = new Scanner(System.in);
		        System.out.print("enter limit: ");
		        x=input.nextInt();
		        isprime=Eratosthenes(x);
		        input.close();
		        for (int k=2;k<=x;k++){
		            for (int l=k+1;l<=x;l++){
		                for (int m=2;m<=x;m++){
		                    if (k+l == m && GCD(k,GCD(l,m))==1 && RAD(k*l*m)<m)
								System.out.println("k: "+k+", l: "+l+", m: "+m+" ");
						}
					}
				}
		}

	public static int GCD(int a, int b){
    	if (b==0)
        	return a;
         else
         	return GCD(b,a%b);
	}

	public static boolean[] Eratosthenes(int x){
    	isprime = new boolean[x+1];
    	isprime[0] = false;
    	isprime[1] = false;
    	for( int i=2;i<x+1;i++){
			isprime[i]= true;
		}
		int p= 2;
   		while (p*p<=x){
    		if (isprime[p] == true){
        		int j= p;
        		while (j<=x/p){
            		isprime[j*p]=false;
                	j++;
				}
			}
       		p++;
		}
    	return isprime;
	}

	public static int RAD(int n){
		int radiant = 1;
    	int result = n;
    	boolean isprimefactor[] = new boolean[n+1];
    	int i=2;
    	while (result>1){
    		while (isprime[i]==true && result%i==0){
        		isprimefactor[i]=true;
            	result/=i;
            }
			i++;
		}

    	for(int j=2; j<n+1;j++){
    		if (isprimefactor[j] == true)
        		radiant *= j;
   		}
   		return radiant;
    }
}
