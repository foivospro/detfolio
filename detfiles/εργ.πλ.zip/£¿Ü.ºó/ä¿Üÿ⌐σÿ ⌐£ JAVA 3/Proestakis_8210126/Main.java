import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Airplane a = new Airplane();
        Scanner s = new Scanner(System.in);
        int flag = 0;
        while (flag != -1) {
            System.out.println("Παρακαλώ πατήστε 1 για Πρώτη θέση ή 2 για Οικονομική θέση");
            flag = a.find(s.nextInt());
            if (flag != -1)
                System.out.println("Αριθμος θεσης:" + flag);
            else
                System.out.print("Η επόμενη πτήση είναι σε 3 ώρες");
        }
    }
}


