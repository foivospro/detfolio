public class Airplane {
    private int l1=0;
    private int l2=4;
    private boolean [] table = new boolean [10];

    public int find(int x){
        int p;
        if(x==1 && l1<4) {
            table[l1] = true;
            p = ++l1;
        }
        else if(x==2 && l2<10) {
            table[l2] = true;
            p = ++l2;
        }
        else
            p=-1;
        return p;
    }
}
