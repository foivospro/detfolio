A=[ 1 1 -1 ; 2 3 2;1 2 3];
B=[ 1 ; 3 ;2 ];
rA=rank(A);
rAaug=rank([A B]);
n=size(A,2);
X1=pinv(A)*B;
Z=null(A);
SOL=[0;0;0];
for k1=-10:0.1:10
Q=X1+k1*Z(:,1);
if abs(norm(Q))<4
SOL=[SOL Q];
end
end
SOL=SOL(:,2:size(SOL,2));
figure (1)
[x,y,z] = sphere;
x = x * 4;
y = y * 4;
z = z * 4;
mesh(x,y,z, 'edgecolor', 'b');
hidden off
hold on
plot3(SOL(1,:),SOL(2,:),SOL(3,:),'ro')
axis equal;
xlabel ('x')
ylabel ('y')
zlabel ('z')
grid on