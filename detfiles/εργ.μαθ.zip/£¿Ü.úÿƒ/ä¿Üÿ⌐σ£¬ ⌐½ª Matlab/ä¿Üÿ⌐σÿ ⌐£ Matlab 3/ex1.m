%Suppose a vector L
L=[ 2.7273 3.75    2.000   5.000]

%and a list A of 10 vectors of R4 organised in rows

K=   [ 3/11  1/11  4/15 1/12    ;...
       6/11  9/12  6/15 12/12   ;...
       1/14  5/14  1/2  11/14   ;...
       6/14  12/14 0/14 6/14    ;...
       3/12  19/11 7/10 12/10   ;...
      -1/2   1/2   1/2 -1/2     ;...
        0     0     0   6       ;...
       19/12 0/11 14/11 15/13   ;...
        5/14 11/14 -1/2 -1/14   ;...
       11/14 -1/14 1/2 -5/14  ];
       
 A=[K;L];  
 IP=A*A';
 NormV1=sqrt(sum((A.*A),2));
 NormV2=NormV1*NormV1';
 Z=IP./NormV2;
 location_of_colinear_vectors=find(abs(Z(11,1:end-1)-1)<0.1);
 colinear_to_vector_L=A(1,:);
 u=find(NormV1-1<0.01);

 x=A(u',:);
 new_base=x(2:end,:);
 a=new_base(1,:);
 b=new_base(2,:);
 c=new_base(3,:);
 d=new_base(4,:);
 vec=L;
 
va=  (vec* a') * a 
vb=  (vec* b') * b 
vc=  (vec* c') * c 
vd=  (vec* d') * d 

% Lets check the numbers if we analysed it correctly 
% All three  should be the same
vec_abcd=va+vb+vc+vd 
vec ;
% YEs they are 

% So we did analyse correctly our vec on the 2 bases
%These are the coordinates of our vector vec onthe abc and ABC bases
vec_L_ON_new_base= [ (vec* a') (vec * b') (vec *c') (vec *d') ] 
 
 
 
 %Using my matlab code SampleVectors.m and reviewing the result matrix Z
 %it produces
 
 %1- Find which of the 10 vectors in the list is colinear to vector L
 
 %2- Find in the A list 4 vectors that consist an orthonormal Base  
 %B= <a ,b ,c ,d > of R4 vector space
 
 %3- Analyse vector L on 4 components La Lb Lc Ld over the Base B
 
 %Your code should :
%     a- solve question 1 using find function,
%     b- locate normal vectors (norm=1) using find function
%     c- use manual tests to locate 4 orthogonal to each other vectors
%     d- display the selected  Base B of question 2  
%     e- Use my example of orthnorm.m το analyse vector L on a b c d
%     f- Show that L is correctly analysed as = La+Lb+Lc+Ld 
 

%Attention.   ALWAYS refer to the original vectors in A in your calculations 
% DO NOT COPY PASTE  secondary results   
%example :  
%A1= [ 3/11 1/11 4/15 1/12]
%is completely different from the 4digit result shown in the command window
%
%A1 =
%    0.2727    0.0909    0.2667    0.0833