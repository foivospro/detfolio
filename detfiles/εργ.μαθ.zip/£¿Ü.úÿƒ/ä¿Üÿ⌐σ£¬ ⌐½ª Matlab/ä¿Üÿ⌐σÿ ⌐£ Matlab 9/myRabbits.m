function [OutPop]=rabbits(EV, InitPop,years)
col=['r' 'g' 'b' 'c' 'm' 'y' 'k' 'w'];
XM(:,1)=InitPop;
yi(1,1)=0;
    for i=1:years
        yi(1,i+1)=i;
        XM(:,i+1)=EV*XM(:,i);
    end

hold on 
l=size(EV);
    for j=1:l(1,1)
        plot(yi,XM(j,:),col(j))
    end
 
hold off    
OutPop=XM;
end
