 A0= [0 6 8 ;0.5 0 0 ;0 0.5 0]
 A2= [0 6 8 ;0.6 0 0 ;0 0.4 0]

[V2,D2]=eig(A2)
[V0,D0]=eig(A0)

X2_0=[96 27 5]
X0_0=[97 24 6]

figure(1)
title (' A2 ')
X2_5=myRabbits(A2,X2_0,5)
xlim([0 5])
ylim([0 4500])
figure(2)
title (' A0 ')
X0_5=myRabbits(A0,X0_0,5)
xlim([0 5])
ylim([0 4500])