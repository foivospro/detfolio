A=[ 1 -1 -1 1; 2 -2 1 1 ;5 -5 -2 4];
B=[ 0 ; 0 ;0 ];
rA=rank(A);
rAaug=rank([A B]);
n=size(A,2);
if (rA+2==n && rA==rAaug)
  display ('Rank of A and augmented A are  the same and two less than the number of unknowns') 
  display ('System is underdetermined and has two parameters solutions. ')
  X2=pinv(A)*B;
  X1=A\B;
  %display ('Verify sample solution')
  Z=null(A);
  RS=[0; 0; 0; 0 ];
  i=1;
  for k1=-10:10
  for k2=-10:10
    Q=X1+k1*Z(:,1)+k2*Z(:,2);
  if(Q(:,1)<=5&&Q(:,1)>=-5)
    i=i+1;
    RS=[RS Q];
    endif
    if(i==101)
    break
  endif
  endfor
  endfor
  RS=RS(:,1:(size(RS,2)-1))
  endif