clear
clc
close all

t=linspace (0,2*pi);
face=[10*sin(t);10*cos(t) ];
eye1=[ 6+2*sin(t); 6+2*cos(t)];
eye2=[ -6+2*sin(t); 6+2*cos(t)];
paint=[ face eye1 eye2 ];
mpaint=[ 10+paint(1,:) ; 10+paint(2,:)];

k=0;
for i=8*pi:-(pi/10):0
k=1.8;
D= [ -k/2*cos(i) sin(i) ; -sin(i) -k/2*cos(i)];
D= [ k*cos(i) sin(i) ; -sin(i) k*cos(i)];
dtxpaint= D*mpaint;
hold on
grid on
plot ( dtxpaint(1,:), dtxpaint(2,:),'b')
axis square
axis ([-50 50 -50 50])
pause(0.2)
clf
end