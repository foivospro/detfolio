
function [Y] = yBessel (n,x)
  if n==0 
    Y=-cos(x)./x;
  elseif n==1
    Y=(-cos(x))./(x.^2) - (sin(x)./x);
  elseif n==2
    Y=((-3./x.^2)+1).*(cos(x)./x)-(3*sin(x)./(x.^2));
  elseif n==3
    Y=(-15./x.^3).*(cos(x)./x)-((15./x.^2)-1).*(sin(x)./x) ;
 endif
endfunction
