%One ant takes a stroll on a basketball field and registers its coordinates
% in  line vectors x1 and y1
%His friend a little drunk does the same in line vectors x2 and y2

%1- Plot their paths using blue and red color
%2- Write a matlab-octave function 
%  function dist=odometer(X,Y) that calculates the distance for a given
%  path of X Y cordinates
%3- Continue this ant.m script calculating the s1 s2 distances for the tw
%ants. 
%4- Find a way to check your result for s1 so thath you know your s2 result
% is also correct.

% HINT & TIP. in your function you will need to produce line vectors
% dx and dy

x1=[...
10.0000    9.7662    9.0758    7.9609    6.4739    4.6841    2.6753    0.5414   -1.6178   -3.7014   -5.6119 ...
-7.2600   -8.5686   -9.4765   -9.9414   -9.9414   -9.4765   -8.5686   -7.2600   -5.6119   -3.7014   -1.6178 ...
 0.5414    2.6753    4.6841    6.4739    7.9609    9.0758    9.7662   10.0000];

y1=[...
 0.000     2.1497    4.1989    6.0517    7.6216    8.8351    9.6355    9.9853    9.8683    9.2898    8.2769 ...
 6.8770    5.1555    3.1930    1.0812   -1.0812   -3.1930   -5.1555   -6.8770   -8.2769   -9.2898   -9.8683 ...
-9.9853   -9.6355   -8.8351   -7.6216   -6.0517   -4.1989   -2.1497   -0.0000];

x2=[...
10.0000    9.5546    8.6825    7.4435    5.9128    4.1767    2.3275    0.4593   -1.3374   -2.9796   -4.3960 ...
-5.5297   -6.3408   -6.8074   -6.9259   -6.7105   -6.1914   -5.4126   -4.4286   -3.3017   -2.0975   -0.8817 ...
 0.2833    1.3421    2.2484    2.9673    3.4764    3.7666    3.8415    3.7168 ];

y2=[...
 0.0000    2.1031    4.0169    5.6584    6.9611    7.8780    8.3829    8.4709    8.1578    7.4783    6.4836 ...
 5.2380    3.8151    2.2937    0.7532   -0.7298   -2.0861   -3.2566   -4.1950   -4.8697   -5.2643   -5.3783 ...
 -5.2258   -4.8339  -4.2410   -3.4933   -2.6427   -1.7426   -0.8456   -0.0000 ];

plot(x1,y1,'b');
hold on 
plot(x2,y2,'r');
[dist]=odometer(x1,y1);
s1=[dist]
[dist]=odometer(x2,y2);
s2=[dist]
t=abs(2*pi*10-s1)<0.9 



