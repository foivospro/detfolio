X=linspace(3,30,9000);
n=[0 1 2 3]
[Y]=yBessel(0,X);
y0=[Y];
[Y]=yBessel(1,X);
y1=[Y];
[Y]=yBessel(2,X);
y2=[Y];
[Y]=yBessel(3,X);
y3=[Y];
plot(X,y0,'b',X,y1,'r',X,y2,'g',X,y3,'m')
Yc=y1(find(abs(y0-y1)<0.00045))
Xc=X(find(abs(y0-y1)<0.00045))
hold on
plot(Xc,Yc,'o','MarkerEdgeColor','k','MarkerFaceColor','y')
x1= Xc(1,1:size(Xc,2)-1);
x2= Xc(1,2:size(Xc,2));
dx=x1-x2;
y1= Yc(1,1:size(Yc,2)-1);
y2= Yc(1,2:size(Yc,2));
dy=y1-y2;
dis=sqrt(dx.^2+dy.^2)
maxdis=max(dis)
ss=find(dis=maxdis)
ymax1=[Yc(ss) Yc(ss+1)]
xmax1=[Xc(ss) Xc(ss+1)]
hold on
plot(xmax1,ymax1,'-ko','LineWidth',3,'MarkerEdgeColor','k','MarkerFaceColor','w')
  
  
  

