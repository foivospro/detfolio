function dist=odometer(X,Y)
  x1= X(1,1:size(X,2)-1);
  x2= X(1,2:size(X,2));
  dx=x1-x2;
  y1= Y(1,1:size(Y,2)-1);
  y2= Y(1,2:size(Y,2));
  dy=y1-y2;
  dist=sum(sqrt(dx.^2+dy.^2));
endfunction
