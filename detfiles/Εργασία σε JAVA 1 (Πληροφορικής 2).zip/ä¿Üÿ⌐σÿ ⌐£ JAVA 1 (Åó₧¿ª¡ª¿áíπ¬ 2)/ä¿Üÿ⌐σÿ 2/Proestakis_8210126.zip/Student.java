import java.util.Scanner;

public class Student{

	double grade1;
	double grade2;
	double average;
	String name;

    public Student(String studentName){
		name = studentName;
	}
    public void inputGrades(){
    	Scanner input = new Scanner( System.in );
    	System.out.println( "Enter the first grade for " + name);
    	grade1 = input.nextDouble();
    	System.out.println( "Enter the second grade for "+ name);
    	grade2 = input.nextDouble();
    }
    public double getAverage(){
   		average = (grade1+grade2)/2;
    	return average;
    }
    public String getName(){
		return name;
	}
}
