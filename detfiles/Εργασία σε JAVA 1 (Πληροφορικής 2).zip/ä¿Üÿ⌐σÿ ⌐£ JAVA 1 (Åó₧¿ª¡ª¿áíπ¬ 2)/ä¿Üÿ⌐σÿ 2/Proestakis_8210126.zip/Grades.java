public class Grades{
	public static void main(String[] args){
		Student student1 = new Student("Mary");
		Student student2 = new Student("Marios");

		student1.inputGrades();
 		System.out.println(student1.name + "'s average is "+student1.getAverage());

 		System.out.println();

		student2.inputGrades();
 		System.out.println(student2.name + "'s average is "+student2.getAverage());
   	}
}